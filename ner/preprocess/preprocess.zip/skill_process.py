from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from typing import Dict, Any, Optional

import pandas as pd

# ========================= CONFIG =========================
CSV_PATH = "../data/raw/raw_skills_list.csv"          # đường dẫn CSV đầu vào
JSON_OUT = "../data/processed/skills_processed.json"  # đường dẫn JSON đầu ra
ID_COL = "id"
NAME_COL = "name"
TYPE_COL = "type.name"        # nếu CSV không có cột này, script sẽ fallback "Hard Skill"
KEEP_TYPE_NAME = False        # True: giữ nguyên type.name; False: map Certification/Hard Skill
INCLUDE_UNIQUE_TOKEN = True   # True để thêm "unique_token" (token xuất hiện duy nhất trong corpus)
INDENT = 2                    # thụt dòng JSON
VERBOSE = 1                   # 0=WARNING, 1=INFO, 2=DEBUG
# ==========================================================


# ---------------------------- Logging ---------------------------------
def setup_logging(verbosity: int) -> None:
    level = logging.WARNING if verbosity <= 0 else (logging.INFO if verbosity == 1 else logging.DEBUG)
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )


# ---------------------------- Cleaning ---------------------------------
PARENS_BLOCK_RE = re.compile(r"\s*[\(\[\{][^)\]\}}]*[\)\]\}]")
PUNCT_RE = re.compile(r"[^a-z0-9\s]+")
SPACE_RE = re.compile(r"\s+")

def clean_label(raw: str) -> str:
    """Lowercase, bỏ phần trong ngoặc, bỏ punctuation, co khoảng trắng."""
    s = (raw or "").lower()
    prev = None
    while prev != s:
        prev = s
        s = PARENS_BLOCK_RE.sub("", s)
    s = PUNCT_RE.sub(" ", s)
    s = SPACE_RE.sub(" ", s).strip()
    return s


# ---------------------------- NLP Fallbacks ----------------------------
def try_import_nltk():
    """Thử dùng NLTK; nếu thiếu thì fallback heuristic (không crash)."""
    try:
        from nltk.stem import PorterStemmer, WordNetLemmatizer
        return PorterStemmer(), WordNetLemmatizer()
    except Exception:
        return None, None


def simple_stem_token(t: str) -> str:
    for suf in ("ing", "edly", "ed", "es", "s"):
        if t.endswith(suf) and len(t) > len(suf) + 2:
            return t[: -len(suf)]
    return t


def simple_lemma_token(t: str) -> str:
    irregular = {
        "children": "child", "people": "person", "men": "man", "women": "woman",
        "mice": "mouse", "geese": "goose", "indices": "index", "matrices": "matrix",
        "vertices": "vertex", "data": "data", "series": "series", "species": "species",
    }
    if t in irregular:
        return irregular[t]
    if t.endswith("ies") and len(t) > 3: return t[:-3] + "y"
    if t.endswith("ves") and len(t) > 3: return t[:-3] + "f"
    if t.endswith(("sses", "ches", "shes", "xes", "zes")): return t[:-2]
    if t.endswith("s") and not t.endswith("ss") and len(t) > 3: return t[:-1]
    return t


def stem_text(text: str, porter) -> str:
    toks = text.split()
    if porter:
        try:
            return " ".join(porter.stem(t) for t in toks)
        except Exception:
            pass
    return " ".join(simple_stem_token(t) for t in toks)


def lemmatize_text(text: str, wn) -> str:
    toks = text.split()
    if wn:
        try:
            out = [wn.lemmatize(t, pos="v") for t in toks]
            out = [wn.lemmatize(t, pos="n") for t in out]
            out = [wn.lemmatize(t, pos="a") for t in out]
            return " ".join(out)
        except Exception:
            pass
    return " ".join(simple_lemma_token(t) for t in toks)


# ---------------------------- Helpers ----------------------------------
@dataclass
class Columns:
    id: str = "id"
    name: str = "name"
    type_name: Optional[str] = "type.name"


def map_skill_type(raw: str, keep_type_name: bool) -> str:
    if keep_type_name:
        return (raw or "").strip() or "Hard Skill"
    if isinstance(raw, str) and raw.strip().lower() == "certification":
        return "Certification"
    return "Hard Skill"


def validate_columns(df: pd.DataFrame, cols: Columns) -> None:
    missing = [c for c in [cols.id, cols.name] if c not in df.columns]
    if missing:
        raise SystemExit(f"Missing required column(s): {', '.join(missing)}")


def compute_unique_tokens(cleaned_series: pd.Series) -> Dict[str, int]:
    from collections import Counter
    cnt = Counter(tok for s in cleaned_series for tok in s.split())
    return dict(cnt)


def build_processed(
    df: pd.DataFrame, cols: Columns,
    keep_type_name: bool, include_unique_token: bool
) -> Dict[str, Dict[str, Any]]:
    df = df.copy()
    df["skill_cleaned"] = df[cols.name].astype(str).map(clean_label)
    df["skill_len"] = df["skill_cleaned"].str.split().str.len()

    porter, wn = try_import_nltk()
    logging.debug("NLTK Porter available: %s; WordNetLemmatizer: %s", bool(porter), bool(wn))

    df["skill_stemmed"] = df["skill_cleaned"].map(lambda s: stem_text(s, porter))
    df["skill_lemmed"] = df["skill_cleaned"].map(lambda s: lemmatize_text(s, wn))

    if cols.type_name and cols.type_name in df.columns:
        df["skill_type"] = df[cols.type_name].astype(str).map(lambda x: map_skill_type(x, keep_type_name))
    else:
        df["skill_type"] = "Hard Skill"

    # Unique token (tuỳ chọn)
    if include_unique_token:
        uniq = compute_unique_tokens(df["skill_cleaned"])
        def first_unique_token(cleaned: str) -> str:
            for tok in cleaned.split():
                if uniq.get(tok, 0) == 1:
                    return tok
            return ""
        df["unique_token"] = df["skill_cleaned"].map(first_unique_token)

    # match_on_stemmed
    df["match_on_stemmed"] = df["skill_len"].eq(1)

    # Sắp xếp theo ID để ổn định
    if cols.id in df.columns:
        df = df.sort_values(by=[cols.id], kind="mergesort")

    records: Dict[str, Dict[str, Any]] = {}
    for _, r in df.iterrows():
        d = {
            "skill_name": str(r[cols.name]),
            "skill_cleaned": str(r["skill_cleaned"]),
            "skill_type": str(r["skill_type"]),
            "skill_lemmed": str(r["skill_lemmed"]),
            "skill_stemmed": str(r["skill_stemmed"]),
            "skill_len": int(r["skill_len"]),
            "match_on_stemmed": bool(r["match_on_stemmed"]),
        }
        if include_unique_token:
            d["unique_token"] = str(r.get("unique_token", "") or "")
        records[str(r[cols.id])] = d

    return records


def run():
    setup_logging(VERBOSE)
    cols = Columns(id=ID_COL, name=NAME_COL, type_name=TYPE_COL)

    logging.info("Reading CSV: %s", CSV_PATH)
    df = pd.read_csv(CSV_PATH)
    validate_columns(df, cols)

    logging.info("Processing %d records...", len(df))
    processed = build_processed(
        df,
        cols=cols,
        keep_type_name=KEEP_TYPE_NAME,
        include_unique_token=INCLUDE_UNIQUE_TOKEN,
    )

    logging.info("Writing JSON: %s", JSON_OUT)
    with open(JSON_OUT, "w", encoding="utf-8") as f:
        json.dump(processed, f, ensure_ascii=False, indent=INDENT, sort_keys=False)

    # Summary
    n = len(processed)
    n_cert = sum(1 for v in processed.values() if v.get("skill_type") == "Certification")
    n_single = sum(1 for v in processed.values() if v.get("match_on_stemmed"))
    logging.info("Done. %d skills written. Certifications: %d. Single-token: %d.",
                 n, n_cert, n_single)


if __name__ == "__main__":
    run()
