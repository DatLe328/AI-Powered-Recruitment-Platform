# sanity_check_spacy_docbin.py
import spacy
from spacy.tokens import DocBin

for path in ["data/spacy/train.spacy", "data/spacy/dev.spacy"]:
    try:
        db = DocBin().from_disk(path)
    except Exception as e:
        print(f"[ERR] Cannot read {path}: {e}")
        continue
    docs = list(db.get_docs(spacy.blank("xx").vocab))
    ents_counts = [len(d.ents) for d in docs]
    print(f"{path}: #docs={len(docs)}  #ents total={sum(ents_counts)}  sample(10)={ents_counts[:10]}")