import re, json, hashlib, collections, unicodedata, argparse
import pandas as pd

def basic_clean(text):
    text = str(text).strip()
    text = re.sub(r"[\(\[\{].*?[\)\]\}]", "", text)
    text = text.lower()
    text = re.sub(r"[^0-9a-zA-Z\u00C0-\u024F\u1E00-\u1EFF\+\#\-\_ ]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def naive_stem(tok):
    if len(tok) <= 3: return tok
    for suf in ["ing","ized","ised","ness","ment","ation","ations","ities","ity","able","ible","ally","ing","ed","es","s"]:
        if tok.endswith(suf) and len(tok)-len(suf) >= 3:
            return tok[:-len(suf)]
    if tok.endswith("ies") and len(tok)>3: return tok[:-3]+"y"
    return tok

def stem_phrase(p): return " ".join(naive_stem(t) for t in p.split())

def extract_abv(raw):
    # lấy chuỗi VIẾT HOA >=2 ký tự (ví dụ: "NLP", "3GPP2")
    return re.findall(r"\b[A-Z0-9]{2,}\b", str(raw))

def main(csv, out_path):
    df = pd.read_csv(csv)
    # đoán cột tên/type
    def pick(cols):
        low = {c.lower(): c for c in df.columns}
        for cand in cols:
            if cand in low: return low[cand]
        for c in df.columns:
            if any(k in c.lower() for k in cols): return c
        return None
    name_col = pick(["skill_name","skill","name","label","title"])
    type_col = pick(["skill_type","type","category","class"])

    if not name_col:
        raise SystemExit("Không tìm thấy cột tên kỹ năng (vd: skill_name/skill/name)")

    # ---------- B1: skills_processed ----------
    skills_processed = {}
    for _, r in df.iterrows():
        raw = str(r[name_col]).strip()
        if not raw or raw.lower()=="nan": continue
        clean = basic_clean(raw)
        if not clean: continue
        skill_len = len(clean.split())
        stemmed = stem_phrase(clean)
        lemmed  = clean  # giản lược đơn giản
        abvs = extract_abv(raw)
        match_on_stemmed = (skill_len == 1)
        skill_type = (str(r[type_col]).strip() if type_col and pd.notna(r[type_col]) else "Hard Skill")
        skill_id = "CU" + hashlib.md5(raw.encode("utf-8")).hexdigest().upper()[:16]
        skills_processed[skill_id] = {
            "skill_name": raw,
            "skill_type": skill_type,
            "skill_cleaned": clean,
            "skill_len": skill_len,
            "skill_stemmed": stemmed,
            "skill_lemmed": lemmed,
            "match_on_stemmed": match_on_stemmed,
            "abbreviation": (abvs[0] if abvs else "")
        }

    # ---------- B2: token_dist ----------
    ngrams = [v["skill_cleaned"] for v in skills_processed.values() if v["skill_len"]>1]
    toks = []
    for n in ngrams: toks += n.split()
    token_dist = dict(collections.Counter(toks))

    # ---------- B3: skill_db_relax_20 ----------
    new_db = {}
    for sid, rec in skills_processed.items():
        high = {}
        low = []
        match_on_tokens = False
        L = rec["skill_len"]
        clean = rec["skill_cleaned"]
        stem = rec["skill_stemmed"]
        lem  = rec["skill_lemmed"]
        abv  = rec["abbreviation"]

        if abv: high["abv"] = abv
        if L == 1:
            high["full"] = clean
            if rec["match_on_stemmed"]:
                low.append(stem)
        elif L == 2:
            high["full"] = lem
            stoks = stem.split()
            low.append(stem)                        # dạng stemmed
            low.append(" ".join(reversed(stoks)))   # dạng đảo
            last = stoks[-1]
            if token_dist.get(last, 0) == 1:        # token cuối “duy nhất”
                low.append(last)
        else:
            high["full"] = lem
            match_on_tokens = True                  # bật token-scanner cho >2-gram

        # thêm abv cho >2-gram nếu duy nhất trong toàn tập
        if L > 2 and abv:
            # chỉ thêm nếu viết tắt này hầu như duy nhất (ở đây giữ nguyên)
            if abv not in low: low.append(abv)

        new_db[sid] = {
            "skill_name": rec["skill_name"],
            "skill_type": rec["skill_type"],
            "skill_len": L,
            "high_surfce_forms": high,
            "low_surface_forms": low,
            "match_on_tokens": match_on_tokens
        }

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(new_db, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    main('data/raw/raw_skills_list.csv', 'data/processed/skill_db.json')
