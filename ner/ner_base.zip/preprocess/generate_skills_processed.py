from __future__ import annotations

import argparse
import json
import logging
import re
from dataclasses import dataclass
from typing import Dict, Any, Optional

import pandas as pd


# ---------------------------- Logging ---------------------------------

def setup_logging(verbosity: int) -> None:
    level = logging.WARNING if verbosity <= 0 else logging.INFO if verbosity == 1 else logging.DEBUG
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )


# ---------------------------- Cleaning ---------------------------------

PARENS_BLOCK_RE = re.compile(r"\s*[\(\[\{][^)\]\}}]*[\)\]\}]")
PUNCT_RE = re.compile(r"[^a-z0-9\s]+")
SPACE_RE = re.compile(r"\s+")
UPPER_TOKEN_RE = re.compile(r"\b[A-Z]{2,}\b")


def clean_label(raw: str) -> str:
    s = (raw or "").lower()
    prev = None
    while prev != s:
        prev = s
        s = PARENS_BLOCK_RE.sub("", s)
    s = PUNCT_RE.sub(" ", s)
    s = SPACE_RE.sub(" ", s).strip()
    return s


# ---------------------------- NLP Fallbacks ----------------------------

def try_import_nltk():
    try:
        from nltk.stem import PorterStemmer, WordNetLemmatizer
        return PorterStemmer(), WordNetLemmatizer()
    except Exception:
        return None, None


def simple_stem_token(t: str) -> str:
    for suf in ("ing", "edly", "edly", "ed", "es", "s"):
        if t.endswith(suf) and len(t) > len(suf) + 2:
            return t[: -len(suf)]
    return t


def simple_lemma_token(t: str) -> str:
    """Tiny heuristic lemmatizer for plural -> singular and common cases (offline-safe)."""
    irregular = {
        "children": "child",
        "people": "person",
        "men": "man",
        "women": "woman",
        "mice": "mouse",
        "geese": "goose",
        "indices": "index",
        "matrices": "matrix",
        "vertices": "vertex",
        "data": "data",
        "series": "series",
        "species": "species",
    }
    if t in irregular:
        return irregular[t]
    if t.endswith("ies") and len(t) > 3:
        return t[:-3] + "y"
    if t.endswith("ves") and len(t) > 3:
        # wolves -> wolf; knives -> knife (approximate)
        return t[:-3] + "f"
    if t.endswith(("sses", "ches", "shes", "xes", "zes")):
        return t[:-2]
    if t.endswith("s") and not t.endswith("ss") and len(t) > 3:
        return t[:-1]
    return t


def stem_text(text: str, porter) -> str:
    tokens = text.split()
    if porter:
        try:
            return " ".join(porter.stem(t) for t in tokens)
        except Exception:
            pass
    return " ".join(simple_stem_token(t) for t in tokens)


def lemmatize_text(text: str, wn) -> str:
    tokens = text.split()
    if wn:
        try:
            # Try multiple POS passes. If WordNet data is missing, this likely raises LookupError.
            out = [wn.lemmatize(t, pos="v") for t in tokens]
            out = [wn.lemmatize(t, pos="n") for t in out]
            out = [wn.lemmatize(t, pos="a") for t in out]
            return " ".join(out)
        except Exception:
            pass
    # Fallback: simple heuristics
    return " ".join(simple_lemma_token(t) for t in tokens)


# ---------------------------- Abbreviation helpers ---------------------

def infer_abbreviation_from_name(raw_name: str) -> str:
    """Extract an uppercase abbreviation (ASQ, NLP, etc.) from the ORIGINAL name (not cleaned)."""
    if not raw_name:
        return ""
    candidates = UPPER_TOKEN_RE.findall(raw_name)
    # Prefer the last (often the actual acronym), else first
    return candidates[-1] if candidates else ""


def build_abbr_lookup(args) -> Dict[str, str]:
    """Build a lookup dict for abbreviations (by id and by name)."""
    lookup: Dict[str, str] = {}

    # 1) From JSON mapping
    if args.abbr_json:
        with open(args.abbr_json, "r", encoding="utf-8") as f:
            j = json.load(f)
        for k, v in j.items():
            if isinstance(v, str) and v:
                lookup[str(k)] = v

    # 2) From CSV mapping
    if args.abbr_csv:
        df = pd.read_csv(args.abbr_csv)
        id_col = args.abbr_id_col or "id"
        name_col = args.abbr_name_col or "name"
        val_col = args.abbr_value_col or "abbreviation"
        for _, row in df.iterrows():
            ab = str(row[val_col]) if val_col in df.columns and pd.notna(row[val_col]) else ""
            if not ab:
                continue
            if id_col in df.columns and pd.notna(row.get(id_col, None)):
                lookup[str(row[id_col])] = ab
            if name_col in df.columns and pd.notna(row.get(name_col, None)):
                lookup[str(row[name_col])] = ab

    return lookup


# ---------------------------- Config & Main ----------------------------

@dataclass
class Columns:
    id: str = "id"
    name: str = "name"
    type_name: Optional[str] = "type.name"


def map_skill_type(raw: str, keep_type_name: bool) -> str:
    """Map type.name to expected values; or keep as-is."""
    if keep_type_name:
        return (raw or "").strip() or "Hard Skill"
    if isinstance(raw, str) and raw.strip().lower() == "certification":
        return "Certification"
    return "Hard Skill"


def validate_columns(df: pd.DataFrame, cols: Columns) -> None:
    missing = [c for c in [cols.id, cols.name] if c not in df.columns]
    if missing:
        raise SystemExit(f"Missing required column(s): {', '.join(missing)}")


def compute_unique_tokens(cleaned_series: pd.Series) -> Dict[str, int]:
    # Count occurrences of tokens across whole corpus
    from collections import Counter
    cnt = Counter(tok for s in cleaned_series for tok in s.split())
    return dict(cnt)


def build_processed(
    df: pd.DataFrame, cols: Columns, abbr_lookup: Dict[str, str],
    keep_type_name: bool, include_unique_token: bool, infer_abbr: bool
) -> Dict[str, Dict[str, Any]]:
    # Clean & basic columns
    df = df.copy()
    df["skill_cleaned"] = df[cols.name].astype(str).map(clean_label)
    df["skill_len"] = df["skill_cleaned"].str.split().str.len()

    # NLP tools (may be None if not available)
    porter, wn = try_import_nltk()
    logging.debug("NLTK Porter: %s; WordNetLemmatizer: %s", bool(porter), bool(wn))

    df["skill_stemmed"] = df["skill_cleaned"].map(lambda s: stem_text(s, porter))
    df["skill_lemmed"] = df["skill_cleaned"].map(lambda s: lemmatize_text(s, wn))

    # Type mapping
    if cols.type_name and cols.type_name in df.columns:
        df["skill_type"] = df[cols.type_name].astype(str).map(lambda x: map_skill_type(x, keep_type_name))
    else:
        df["skill_type"] = "Hard Skill"

    # Abbreviation
    def resolve_abbr(row) -> str:
        # Priority: abbr_lookup by id -> name -> optional CSV column
        sid = str(row[cols.id])
        sname = str(row[cols.name])

        if sid in abbr_lookup:
            return abbr_lookup[sid]
        if sname in abbr_lookup:
            return abbr_lookup[sname]
        return infer_abbreviation_from_name(sname) if infer_abbr else ""

    df["abbreviation"] = df.apply(resolve_abbr, axis=1)

    # Unique token (optional)
    unique_token_map: Dict[str, int] = {}
    if include_unique_token:
        unique_token_map = compute_unique_tokens(df["skill_cleaned"])

        def first_unique_token(cleaned: str) -> str:
            for tok in cleaned.split():
                if unique_token_map.get(tok, 0) == 1:
                    return tok
            return ""

        df["unique_token"] = df["skill_cleaned"].map(first_unique_token)

    # match_on_stemmed
    df["match_on_stemmed"] = df["skill_len"].eq(1)

    # Assemble dict keyed by ID (stable sort by ID to ensure determinism)
    df = df.sort_values(by=[cols.id], kind="mergesort")
    fields = ["skill_name", "skill_cleaned", "skill_type", "skill_lemmed", "skill_stemmed",
              "skill_len", "abbreviation", "match_on_stemmed"]
    if include_unique_token:
        fields.insert(7, "unique_token")  # put before match_on_stemmed

    records: Dict[str, Dict[str, Any]] = {}
    for _, r in df.iterrows():
        d = {
            "skill_name": str(r[cols.name]),
            "skill_cleaned": str(r["skill_cleaned"]),
            "skill_type": str(r["skill_type"]),
            "skill_lemmed": str(r["skill_lemmed"]),
            "skill_stemmed": str(r["skill_stemmed"]),
            "skill_len": int(r["skill_len"]),
            "abbreviation": str(r["abbreviation"] or ""),
            "match_on_stemmed": bool(r["match_on_stemmed"]),
        }
        if include_unique_token:
            d["unique_token"] = str(r.get("unique_token", "") or "")
        records[str(r[cols.id])] = d

    return records


def parse_args():
    ap = argparse.ArgumentParser(description="Create skills_processed.json from a raw skills CSV.")
    ap.add_argument("--csv_path", default="../data/raw/raw_skills_list.csv", help="Input CSV (e.g., raw_skills_list.csv)")
    ap.add_argument("--json_out", default="../data/processed/skills_processed.json", help="Output JSON path (skills_processed.json)")
    ap.add_argument("--id-col", default="id")
    ap.add_argument("--name-col", default="name")
    ap.add_argument("--type-col", default="type.name")
    # Abbreviation sources
    ap.add_argument("--abbr-col", help="(Unused here; provide via --abbr-csv/--abbr-json).", default=None)
    ap.add_argument("--abbr-json", help="JSON file: {id|name: abbreviation}", default=None)
    ap.add_argument("--abbr-csv", help="CSV mapping: columns defined by flags below", default=None)
    ap.add_argument("--abbr-id-col", help="ID column in abbr CSV", default="id")
    ap.add_argument("--abbr-name-col", help="Name column in abbr CSV", default="name")
    ap.add_argument("--abbr-value-col", help="Abbreviation value column in abbr CSV", default="abbreviation")
    ap.add_argument("--infer-abbr", action="store_true", help="Infer abbreviation from UPPERCASE tokens (fallback).")
    # Behavior toggles
    ap.add_argument("--keep-type-name", action="store_true",
                    help="Keep raw values from --type-col instead of mapping to {'Certification','Hard Skill'}.")
    ap.add_argument("--no-unique-token", dest="with_unique", action="store_false",
                    help="Omit 'unique_token' field (included by default).")
    ap.add_argument("--indent", type=int, default=2, help="JSON indent (default 2).")
    ap.add_argument("-v", "--verbose", action="count", default=1, help="Verbosity: -v (info), -vv (debug).")
    return ap.parse_args()


def main():
    args = parse_args()
    setup_logging(args.verbose)

    cols = Columns(id=args.id_col, name=args.name_col, type_name=args.type_col)

    logging.info("Reading CSV: %s", args.csv_path)
    df = pd.read_csv(args.csv_path)
    validate_columns(df, cols)

    abbr_lookup = build_abbr_lookup(args)

    logging.info("Processing %d records...", len(df))
    processed = build_processed(
        df,
        cols=cols,
        abbr_lookup=abbr_lookup,
        keep_type_name=args.keep_type_name,
        include_unique_token=args.with_unique if args.with_unique is not None else True,
        infer_abbr=args.infer_abbr,
    )

    logging.info("Writing JSON: %s", args.json_out)
    with open(args.json_out, "w", encoding="utf-8") as f:
        json.dump(processed, f, ensure_ascii=False, indent=args.indent, sort_keys=False)

    # Summary
    n = len(processed)
    n_cert = sum(1 for v in processed.values() if v.get("skill_type") == "Certification")
    n_single = sum(1 for v in processed.values() if v.get("match_on_stemmed"))
    logging.info("Done. %d skills written. Certifications: %d. Single-token: %d.", n, n_cert, n_single)


if __name__ == "__main__":
    main()
