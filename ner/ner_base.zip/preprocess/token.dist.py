# build_token_dist_stemmed.py
import json, collections
with open('../data/processed/skills_processed.json','r',encoding='utf-8') as f:
    SKILL_DB = json.load(f)

words = []
for k,v in SKILL_DB.items():
    if v.get('skill_len',0) > 1:
        words += (v.get('skill_stemmed','') or '').split()

token_dist = dict(collections.Counter([w for w in words if w]))
with open('../data/processed/token_dist.json','w',encoding='utf-8') as f:
    json.dump(token_dist, f, ensure_ascii=False, indent=2)
