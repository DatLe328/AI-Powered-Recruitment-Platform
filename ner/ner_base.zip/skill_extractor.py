import json
import math
import argparse
from dataclasses import dataclass
from typing import Dict, List, Tuple, Any
import spacy
from spacy.matcher import PhraseMatcher
from spacy.tokens import Doc

# -------------------------- Utilities --------------------------
def is_upper_acronym(txt: str) -> bool:
    letters = [c for c in txt if c.isalpha()]
    return len(letters) >= 2 and all(c.isupper() for c in letters)
KNOWN_SHORT_SKILLS = {"C", "R", "C#", "C++"}
STOPWORD_SINGLE_TOKEN = {
    "a","an","the","and","or","as","at","in","on","to","for","of","by","is","are","be","with","from"
}
def normalize_ws(text: str) -> str:
    return " ".join(str(text).split())

@dataclass
class Skill:
    skill_id: str
    name: str
    type: str
    length: int
    high_full: str
    high_abv: str
    low_forms: List[str]
    match_on_tokens: bool

# -------------------------- Indexer ----------------------------

class SkillIndex:
    def __init__(self, nlp, attr="LOWER"):
        self.nlp = nlp
        self.attr = attr
        self.high = PhraseMatcher(nlp.vocab, attr=attr)
        self.low  = PhraseMatcher(nlp.vocab, attr=attr)
        self.low_acronym = PhraseMatcher(nlp.vocab, attr="ORTH") 
        self.skills: Dict[str, Skill] = {}
        # Reverse maps for low/high forms (for conflict resolution / debug)
        self._form_to_ids_high: Dict[str, List[str]] = {}
        self._form_to_ids_low: Dict[str, List[str]] = {}

    def add_skill(self, skill: Skill):
        self.skills[skill.skill_id] = skill
        self._abv_vocab = set()
        patterns_high = []
        if skill.high_full:
            patterns_high.append(skill.high_full)
            self._form_to_ids_high.setdefault(skill.high_full.lower(), []).append(skill.skill_id)
        if skill.high_abv:
            patterns_high.append(skill.high_abv)
            self._form_to_ids_high.setdefault(skill.high_abv.lower(), []).append(skill.skill_id)
            self._abv_vocab.add(skill.high_abv.lower())
        if patterns_high:
            self.high.add(skill.skill_id, [self.nlp.make_doc(p) for p in patterns_high])

        patterns_low_normal = []
        patterns_low_acr = []
        for lf in (skill.low_forms or []):
            lf_norm = normalize_ws(lf)
            if not lf_norm:
                continue
            # nếu là viết tắt (AT, WHO, NLP, ...) hoặc short-skill đặc biệt (C, R, C#, C++)
            if is_upper_acronym(lf_norm) or lf_norm in KNOWN_SHORT_SKILLS:
                patterns_low_acr.append(lf_norm)
            else:
                patterns_low_normal.append(lf_norm)
        if patterns_low_normal:
            self.low.add(skill.skill_id, [self.nlp.make_doc(p) for p in patterns_low_normal])
        if patterns_low_acr:
            self.low_acronym.add(skill.skill_id, [self.nlp.make_doc(p) for p in patterns_low_acr])

    @classmethod
    def from_skill_db(cls, nlp, skill_db: Dict[str, Any]):
        idx = cls(nlp, attr="LOWER")
        for sid, rec in skill_db.items():
            high = rec.get("high_surfce_forms", {}) or {}
            skill = Skill(
                skill_id=sid,
                name=rec.get("skill_name",""),
                type=rec.get("skill_type","Hard Skill"),
                length=int(rec.get("skill_len", 1)),
                high_full=normalize_ws(high.get("full","")),
                high_abv=normalize_ws(high.get("abv","")),
                low_forms=[normalize_ws(x) for x in (rec.get("low_surface_forms") or []) if x],
                match_on_tokens=bool(rec.get("match_on_tokens", False))
            )
            # avoid adding empty
            if (skill.high_full or skill.high_abv or skill.low_forms):
                idx.add_skill(skill)
        return idx

# -------------------------- Extractor --------------------------

def _to_span(doc: Doc, start: int, end: int) -> Tuple[int,int,str]:
    span = doc[start:end]
    return (span.start_char, span.end_char, span.text)

def _pick_best_spans(spans: List[Tuple[int,int,dict]], allow_overlaps=False) -> List[Tuple[int,int,dict]]:
    """
    Resolve overlaps. Priority:
      1) longer span wins
      2) source: high > low > token
    """
    if allow_overlaps:
        return spans

    def score(item):
        s,e,data = item
        length = e - s
        src = data.get("source","low")
        src_rank = {"high": 2, "low": 1, "token": 0}.get(src, 0)
        return (length, src_rank)

    spans_sorted = sorted(spans, key=score, reverse=True)
    chosen = []
    for s,e,d in spans_sorted:
        overlap = False
        for cs,ce,_ in chosen:
            if not (e <= cs or s >= ce):
                overlap = True
                break
        if not overlap:
            chosen.append((s,e,d))
    return sorted(chosen, key=lambda x: x[0])

class SkillExtractorFS:
    def __init__(self, enable_token_scanner=True, relax=0.2, allow_overlaps=False):
        self.nlp = spacy.load("en_core_web_lg", exclude=["ner"])
        self.relax = float(relax)
        self.allow_overlaps = allow_overlaps
        self.enable_token_scanner = enable_token_scanner
        with open('data/processed/skill_db_relax_20.json', "r", encoding="utf-8") as f:
            skill_db = json.load(f)
        self.index = SkillIndex.from_skill_db(self.nlp, skill_db)
        # precompute tokenized forms for token-scanner
        self._token_skills = []
        for s in self.index.skills.values():
            if s.match_on_tokens and s.length > 2:
                toks = [t for t in s.high_full.lower().split() if t] if s.high_full else s.name.lower().split()
                # fallback to low_forms first item if no full
                if not toks and s.low_forms:
                    toks = s.low_forms[0].lower().split()
                toks = [t for t in toks if t.isalnum() or len(t)>1]
                if toks:
                    self._token_skills.append((s.skill_id, toks))

    def annotate(self, text: str) -> Dict[str, Any]:
        doc = self.nlp(text)

        # High matches
        high_hits = []
        for sid, starts_ends in self._match_phrase(self.index.high, doc):
            for start, end in starts_ends:
                s_char, e_char, span_text = _to_span(doc, start, end)

                high_hits.append((s_char, e_char, {
                    "skill_id": sid,
                    "source": "high",
                    "match": span_text
                }))

        # Low matches
        low_hits = []
        for sid, starts_ends in self._match_phrase(self.index.low, doc):
            for start, end in starts_ends:
                s_char, e_char, span_text = _to_span(doc, start, end)
                if (end - start) == 1:
                    tok = span_text
                    if tok.islower() and tok.lower() in STOPWORD_SINGLE_TOKEN:
                        continue
                low_hits.append((s_char, e_char, {
                    "skill_id": sid,
                    "source": "low",
                    "match": span_text
                }))

        # Token-scanner (optional, for long skills with match_on_tokens)
        token_hits = []
        if self.enable_token_scanner and self._token_skills:
            token_hits = self._token_window_scanner(doc)

        # Combine and resolve overlaps
        all_hits = high_hits + low_hits + token_hits
        final_spans = _pick_best_spans(all_hits, allow_overlaps=self.allow_overlaps)

        # Build outputs
        results = {
            "full_matches": [],
            "partial_matches": [],
            "token_scanner": []
        }
        unique_skills = {}

        for s_char, e_char, data in final_spans:
            sid = data["skill_id"]
            sdef = self.index.skills.get(sid)
            if not sdef:
                continue
            item = {
                "skill_id": sid,
                "skill_name": sdef.name,
                "skill_type": sdef.type,
                "start": s_char,
                "end": e_char,
                "match": data.get("match",""),
                "source": data.get("source","low")
            }
            if item["source"] == "high":
                results["full_matches"].append(item)
            elif item["source"] == "token":
                results["token_scanner"].append(item)
            else:
                results["partial_matches"].append(item)

            uni = unique_skills.setdefault(sid, {
                "skill_name": sdef.name,
                "skill_type": sdef.type,
                "occurrences": 0
            })
            uni["occurrences"] += 1

        return {
            "text": text,
            "results": results,
            "unique_skills": unique_skills
        }

    # -------- helpers --------
    def _match_phrase(self, matcher: PhraseMatcher, doc: Doc) -> List[Tuple[str, List[Tuple[int,int]]]]:
        out = {}
        for m_id, start, end in matcher(doc):
            label = self.nlp.vocab.strings[m_id]
            out.setdefault(label, []).append((start, end))
        return list(out.items())

    def _token_window_scanner(self, doc: Doc) -> List[Tuple[int,int,dict]]:
        # Bag-of-words within a window of length len(tokens) + floor(relax * len(tokens))
        # If >= ceil((1-relax) * len(tokens)) tokens are inside the window, mark as hit.
        tokens = [t for t in doc if (t.is_alpha or t.is_digit) and not t.is_space]
        lower = [t.text.lower() for t in tokens]
        hits = []

        for sid, skill_toks in self._token_skills:
            L = len(skill_toks)
            if L < 3:
                continue
            min_needed = math.ceil((1.0 - self.relax) * L)
            win = L + max(0, int(self.relax * L))

            # sliding windows over doc
            for i in range(0, max(0, len(lower)-1)):
                j = min(len(lower), i+win)
                window = lower[i:j]
                present = sum(1 for t in set(skill_toks) if t in window)
                if present >= min_needed:
                    # span chars
                    s_char = tokens[i].idx
                    e_char = tokens[j-1].idx + len(tokens[j-1])
                    span_text = doc.text[s_char:e_char]
                    hits.append((s_char, e_char, {
                        "skill_id": sid,
                        "source": "token",
                        "match": span_text
                    }))
        return hits

# -------------------------- CLI -------------------------------

def main():
    ap = argparse.ArgumentParser(description="Skill NER (from scratch)")
    ap.add_argument("--text", help="Single input text")
    ap.add_argument("--file", help="Path to a UTF-8 text file to process")
    ap.add_argument("--relax", type=float, default=0.2, help="Relax ratio for token scanner (default 0.2)")
    ap.add_argument("--allow_overlaps", action="store_true", help="Keep overlapping spans (off by default)")
    ap.add_argument("--disable_token_scanner", action="store_true", help="Disable token-scanner step")
    ap.add_argument("--json_out", help="If set, write JSON result to this file")
    args = ap.parse_args()

    if not args.text and not args.file:
        ap.error("Provide --text or --file")

    extractor = SkillExtractorFS()


    if args.file:
        with open(args.file, "r", encoding="utf-8") as f:
            text = f.read()
    else:
        text = args.text

    out = extractor.annotate(text)

    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=2)
    else:
        print(json.dumps(out, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
