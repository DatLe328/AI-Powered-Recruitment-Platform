import argparse
import random
from pathlib import Path
from typing import List, Tuple

import spacy
from spacy.tokens import DocBin
from spacy.training import Example
from spacy.util import minibatch, fix_random_seed


def load_docbin(path: str) -> List:
    db = DocBin().from_disk(path)
    return list(db.get_docs(spacy.blank("xx").vocab))


def docs_to_examples(nlp, docs) -> List[Example]:
    """Chuyển list Doc (đã có .ents) -> spaCy Examples (text + gold spans)."""
    exs = []
    for gold_doc in docs:
        pred_doc = nlp.make_doc(gold_doc.text)
        # lấy entities theo char offsets
        spans = [(ent.start_char, ent.end_char, ent.label_) for ent in gold_doc.ents]
        exs.append(Example.from_dict(pred_doc, {"entities": spans}))
    return exs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", default='data/spacy/train.spacy', help="Đường dẫn train.spacy")
    ap.add_argument("--dev", default='data/spacy/dev.spacy', help="Đường dẫn dev.spacy")
    ap.add_argument("--lang", default="en", help="Mã ngôn ngữ spaCy blank để tokenize (vd: en/vi)")
    ap.add_argument("--output", default='models/', help="Thư mục lưu model đã train")
    ap.add_argument("--n_iter", type=int, default=30)
    ap.add_argument("--batch_size", type=int, default=128)
    ap.add_argument("--dropout", type=float, default=0.2)
    ap.add_argument("--seed", type=int, default=13)
    ap.add_argument("--gpu", type=int, default=-1, help="GPU id (mặc định -1 = CPU)")
    args = ap.parse_args()

    if args.gpu >= 0:
        spacy.require_gpu(args.gpu)

    fix_random_seed(args.seed)
    random.seed(args.seed)

    # 1) Load dữ liệu
    train_docs = load_docbin(args.train)
    dev_docs   = load_docbin(args.dev)

    # 2) Tạo nlp blank + pipeline NER
    nlp = spacy.blank(args.lang)  # tokenizer rỗng theo ngôn ngữ
    if "ner" not in nlp.pipe_names:
        ner = nlp.add_pipe("ner")
    else:
        ner = nlp.get_pipe("ner")

    # 3) Thu nhãn từ dữ liệu train
    labels = set()
    for d in train_docs:
        for ent in d.ents:
            labels.add(ent.label_)
    for lb in sorted(labels):
        ner.add_label(lb)
    print(f"[INFO] Labels: {sorted(labels)}")

    # 4) Tạo Examples
    train_examples = docs_to_examples(nlp, train_docs)
    dev_examples   = docs_to_examples(nlp, dev_docs)

    # 5) Khởi tạo & train
    optimizer = nlp.initialize(get_examples=lambda: train_examples)
    print("[INFO] Initialized. Start training...")
    best_f = -1.0
    best_path = Path(args.output)
    best_path.mkdir(parents=True, exist_ok=True)

    for epoch in range(1, args.n_iter + 1):
        random.shuffle(train_examples)
        losses = {}
        for batch in minibatch(train_examples, size=args.batch_size):
            nlp.update(batch, sgd=optimizer, losses=losses, drop=args.dropout)
        # evaluate
        scores = nlp.evaluate(dev_examples)
        ents_p = scores["ents_p"]
        ents_r = scores["ents_r"]
        ents_f = scores["ents_f"]
        print(f"Epoch {epoch:03d} | Loss {losses.get('ner', 0):.2f} | P {ents_p:.3f} R {ents_r:.3f} F {ents_f:.3f}")

        # lưu best theo F1
        if ents_f > best_f:
            best_f = ents_f
            nlp.to_disk(best_path)
            print(f"  -> Saved BEST model to: {best_path} (F1={best_f:.3f})")

    print(f"[DONE] Best F1: {best_f:.3f} | Model dir: {best_path}")


if __name__ == "__main__":
    main()
