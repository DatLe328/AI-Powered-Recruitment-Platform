# Spacy config

```bash
python -m spacy init config configs/ner.cfg --lang en --pipeline ner --optimize efficiency
```
