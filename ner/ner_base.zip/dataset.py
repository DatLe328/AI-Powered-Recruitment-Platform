import argparse
import json
import random
from pathlib import Path
from typing import List, Tuple

import spacy
from spacy.tokens import Doc, Span
from spacy.tokens import DocBin
from spacy.util import filter_spans

# ---------------------- Import your SkillExtractorFS ----------------------

def load_skill_extractor():
    from skill_extractor import SkillExtractorFS 
    extractor = SkillExtractorFS()
    return extractor

# ---------------------- I/O helpers ----------------------

def read_texts_from_dir(dir_path: str) -> List[Tuple[str, str]]:
    items: List[Tuple[str, str]] = []
    for p in sorted(Path(dir_path).glob("**/*.txt")):
        items.append((p.name, p.read_text(encoding="utf-8", errors="ignore")))
    return items

def read_texts_from_csv(csv_path: str, text_col: str) -> List[Tuple[str, str]]:
    import pandas as pd
    df = pd.read_csv(csv_path)
    if text_col not in df.columns:
        raise SystemExit(f"Column '{text_col}' not found in CSV.")
    rows: List[Tuple[str, str]] = []
    for i, r in df.iterrows():
        rows.append((str(r.get("id", i)), str(r[text_col]) if r[text_col] is not None else ""))
    return rows

# ---------------------- Label + span utils ----------------------

def choose_label(skill_type: str, strategy: str) -> str:
    if strategy == "single":
        return "SKILL"
    # strategy == "type"
    if not skill_type:
        return "SKILL"
    return skill_type.strip().upper().replace(" ", "_").replace("-", "_")

def normalize_hits(results_dict, include_sources=("high","low")) -> List[Tuple[int,int,str]]:
    """
    Convert từ dict 'results' của extractor -> danh sách (start, end, label="SKILL").
    include_sources: lấy từ high, low, token.
    """
    allowed = {s.lower() for s in include_sources}
    spans = []
    for key in ("full_matches", "partial_matches", "token_scanner"):
        for it in results_dict.get(key, []):
            src = str(it.get("source", "low")).lower()
            if src not in allowed:
                continue
            s = int(it.get("start", 0))
            e = int(it.get("end", 0))
            if e - s < 2:
                continue
            spans.append((s, e, it.get("skill_type", "Hard Skill")))
    # Giải chồng lấn: chọn span dài nhất trước
    spans = sorted(spans, key=lambda x: (-(x[1]-x[0]), x[0]))
    chosen = []
    for s,e,t in spans:
        if all(e <= cs or s >= ce for cs,ce,_ in chosen):
            chosen.append((s,e,t))
    return sorted(chosen, key=lambda x: x[0])

def make_doc(nlp_blank, text: str, ents: List[Tuple[int,int,str]], label_strategy: str) -> Doc:
    """
    ents: danh sách (start, end, skill_type). Sẽ map sang label cuối cùng rồi set doc.ents
    """
    doc = nlp_blank.make_doc(text)
    spans: List[Span] = []
    for s, e, skill_type in ents:
        label = choose_label(skill_type, label_strategy)
        sp = doc.char_span(s, e, label=label, alignment_mode="strict")
        if sp is None:
            sp = doc.char_span(s, e, label=label, alignment_mode="contract")
        if sp is None:
            sp = doc.char_span(s, e, label=label, alignment_mode="expand")
        if sp is not None:
            spans.append(sp)
    # spaCy yêu cầu không chồng lấn entity
    spans = filter_spans(spans)
    doc.ents = spans
    return doc

# ---------------------- Main ----------------------

def main():
    # load extractor từ module của bạn
    extractor = load_skill_extractor()

    items = read_texts_from_csv('test.csv', 'data')

    # tokenizer rỗng cho build Doc
    nlp_blank = spacy.blank("en")
    include_sources = [s.strip() for s in "high,low".split(",") if s.strip()]

    docs: List[Doc] = []
    for name, text in items:
        ann = extractor.annotate(text)          # {'text':..., 'results': {...}, 'unique_skills': {...}}
        res = ann.get("results", {})
        ents = normalize_hits(res, include_sources=include_sources)
        doc = make_doc(nlp_blank, text, ents, "single")
        docs.append(doc)

    # chia train/dev ngẫu nhiên
    rng = random.Random(13)
    idxs = list(range(len(docs)))
    n_docs = len(docs)
    if n_docs == 0:
        raise SystemExit("[ERROR] No docs to write. Kiểm tra bước gán nhãn từ extractor.")
    rng.shuffle(idxs)
    if n_docs == 1:
        # duy nhất 1 doc -> đưa hết vào train, dev rỗng
        dev_idxs = set()
    else:
        # đảm bảo còn ít nhất 1 doc cho train
        n_dev = int(round(n_docs * 0.2))
        n_dev = max(1, n_dev)                  # có dev
        if n_dev >= n_docs:                    # không nuốt hết train
            n_dev = n_docs - 1
        dev_idxs = set(idxs[:n_dev])

    db_train, db_dev = DocBin(store_user_data=False), DocBin(store_user_data=False)
    for i, d in enumerate(docs):
        (db_dev if i in dev_idxs else db_train).add(d)

    out_dir = Path("data") / "spacy"
    out_dir.mkdir(parents=True, exist_ok=True)

    train_file = out_dir / "train.spacy"
    dev_file   = out_dir / "dev.spacy"

    db_train.to_disk(train_file)
    db_dev.to_disk(dev_file)

    print(f"[OK] Wrote: {train_file} (train)")
    print(f"[OK] Wrote: {dev_file} (dev)")

if __name__ == "__main__":
    main()
